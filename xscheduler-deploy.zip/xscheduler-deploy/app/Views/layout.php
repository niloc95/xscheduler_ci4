<link rel="stylesheet" href="<?= base_url('build/style.css') ?>">
<script src="<?= base_url('build/main.js') ?>" defer></script>
