<?php

namespace App\Controllers;

class Tw extends BaseController
{
    public function tw(): string
    {
        return view('tw');
    }
  
}
